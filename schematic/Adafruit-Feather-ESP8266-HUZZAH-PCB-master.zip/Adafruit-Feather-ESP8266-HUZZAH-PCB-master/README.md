# Adafruit-Feather-ESP8266-HUZZAH-PCB
PCB files for the Adafruit Feather ESP8266 HUZZAH

Format is EagleCAD schematic and board layout

For more details, check out the product page at

  * https://www.adafruit.com/product/2821

Adafruit invests time and resources providing this open source design, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Designed by Adafruit Industries.  
Creative Commons Attribution, Share-Alike license, check license.txt for more information
All text above must be included in any redistribution